<?php
define('ROOT',TRUE);
$config = include '../config/config.php';
?><meta http-equiv="refresh" content="0;url=../index.php?case=install&admin_dir=<?php echo $config['admin_dir'];?>&site=default">