<?php
if (!defined('ROOT'))
    exit('Can\'t Access !');
include dirname(dirname(__FILE__)).'/admin/template_.php';