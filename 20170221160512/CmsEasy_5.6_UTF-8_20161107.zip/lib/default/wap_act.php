<?php
/*if (!defined('ROOT'))
    exit('Can\'t Access !');
class wap_act extends act {
    function index_action() {
    }
    function end() {
        $this->render();
    }
}*/