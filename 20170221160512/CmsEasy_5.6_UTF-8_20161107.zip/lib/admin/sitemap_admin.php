<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class sitemap_admin extends admin {
    
}