<?php

define('_VERSION','5_6_0_20161107_UTF8');
define('_VERNUM','5.6.0.20161107');