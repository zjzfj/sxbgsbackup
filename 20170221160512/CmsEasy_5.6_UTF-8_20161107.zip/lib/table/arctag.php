<?php

class arctag extends table {

    public  $name='b_arctag';

}